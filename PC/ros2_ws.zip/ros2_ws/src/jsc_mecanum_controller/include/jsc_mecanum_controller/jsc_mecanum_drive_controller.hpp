
#ifndef __JSC_MECANUM_CONTROLLER__MECANUM_DRIVE_CONTROLLER_H__
#define __JSC_MECANUM_CONTROLLER__MECANUM_DRIVE_CONTROLLER_H__

#include <controller_interface/controller_interface.hpp>
#include <rclcpp_lifecycle/node_interfaces/lifecycle_node_interface.hpp>
#include <rclcpp_lifecycle/state.hpp>
#include <realtime_tools/realtime_buffer.h>
#include <geometry_msgs/msg/twist.hpp>
#include <string>

#include "jsc_mecanum_controller/jsc_mecanum_wheel.hpp"
#include "jsc_mecanum_controller/jsc_mecanum_controller_compiler.h"

namespace jsc
{
    namespace mecanumbot
    {
        namespace controller
        {
            using Twist = geometry_msgs::msg::Twist;

            class MecanumbotDriveController
                : public controller_interface::ControllerInterface
            {
            public:
                JSC_MECANUM_CONTROLLER_PUBLIC
                MecanumbotDriveController();
                
                JSC_MECANUM_CONTROLLER_PUBLIC
                controller_interface::InterfaceConfiguration command_interface_configuration() const override;

                JSC_MECANUM_CONTROLLER_PUBLIC
                controller_interface::InterfaceConfiguration state_interface_configuration() const override;

                JSC_MECANUM_CONTROLLER_PUBLIC
                controller_interface::return_type update(const rclcpp::Time & time, const rclcpp::Duration & period) override;

                JSC_MECANUM_CONTROLLER_PUBLIC
                controller_interface::CallbackReturn on_init() override;

                JSC_MECANUM_CONTROLLER_PUBLIC
                controller_interface::CallbackReturn on_configure(const rclcpp_lifecycle::State & previous_state) override;

                JSC_MECANUM_CONTROLLER_PUBLIC
                controller_interface::CallbackReturn on_activate(const rclcpp_lifecycle::State & previous_state) override;

                JSC_MECANUM_CONTROLLER_PUBLIC
                controller_interface::CallbackReturn on_deactivate(const rclcpp_lifecycle::State & previous_state) override;

                JSC_MECANUM_CONTROLLER_PUBLIC
                controller_interface::CallbackReturn on_cleanup(const rclcpp_lifecycle::State & previous_state) override;

                JSC_MECANUM_CONTROLLER_PUBLIC
                controller_interface::CallbackReturn on_error(const rclcpp_lifecycle::State & previous_state) override;

                JSC_MECANUM_CONTROLLER_PUBLIC
                controller_interface::CallbackReturn on_shutdown(const rclcpp_lifecycle::State & previous_state) override;
            
            protected:
                std::shared_ptr<MecanumbotWheel> get_wheel(const std::string & wheel_joint_name);

                bool reset();

            protected:
                rclcpp::Subscription<Twist>::SharedPtr velocity_command_subsciption_;
                realtime_tools::RealtimeBuffer<std::shared_ptr<Twist>> velocity_command_ptr_;
                std::shared_ptr<MecanumbotWheel> fl_wheel_;
                std::shared_ptr<MecanumbotWheel> fr_wheel_;
                std::shared_ptr<MecanumbotWheel> rl_wheel_;
                std::shared_ptr<MecanumbotWheel> rr_wheel_;
                std::string fl_wheel_joint_name_;
                std::string fr_wheel_joint_name_;
                std::string rl_wheel_joint_name_;
                std::string rr_wheel_joint_name_;
                double linear_scale_;
                double radial_scale_;
                double wheel_radius_;
                double wheel_distance_width_;
                double wheel_distance_length_;
                double wheel_separation_width_;
                double wheel_separation_length_;
                bool subscriber_is_active_;

            };
        }
    }
}

#endif // __JSC_MECANUM_CONTROLLER__MECANUM_DRIVE_CONTROLLER_H__
